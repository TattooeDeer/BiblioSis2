class Evento < ActiveRecord::Base
end
