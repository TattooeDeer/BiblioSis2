module NoticiaHelper
end
